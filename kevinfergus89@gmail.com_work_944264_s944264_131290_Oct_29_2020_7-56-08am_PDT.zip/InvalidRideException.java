/**
 * Throw this exception class in TaxiService.validateRide(Ride) method 
 * when the ride is not valid.
 * There is nothing required to do in this class. 
 */
public class InvalidRideException extends Exception{

}
